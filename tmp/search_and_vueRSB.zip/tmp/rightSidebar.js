function vueRightSidebar() {

	var rightSidebar = new Vue({
		el: '#vueRightSidebar',
		data: {
			school: {}
		},
		computed: {
			currSchool: function() { 
				console.log("That's what I thought!");
				return store.state.currSchool;
			},
		},
		watch: {
			watch: {
                currSchool: function(newVal, oldVal) {
                    // this.refreshRightSidebar();
                },
            },
		},
		methods: {
            test123: function() {
                alert("testing");
            },
			refreshRightSidebar: function () {
                var tmp = {"action":"rightsidebar"};
                self = this;
				$.getJSON("api/school.cfm", tmp,
                    function(response) {
                        // console.log(response);                        
                        self.school = response.data[0];                        
                        // console.log(rightSidebar.school);
                    },
					function(response) {
                        // console.log(resp);
						console.log("Fail getCustomFields");
					}
                );
                event.stopPropagation();
			},
		},
		mounted: function() {
            console.log("Right Sidebar component has been mounted!");            
            this.refreshRightSidebar();
		}
	});

	return rightSidebar;
}